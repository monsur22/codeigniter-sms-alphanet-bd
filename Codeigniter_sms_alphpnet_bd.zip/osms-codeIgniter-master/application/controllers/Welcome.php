<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	
	 
	// public function index()
	// {
	// 	try
	// 	{ 	
	// 		//Register free demo account from https://onnorokomsms.com
			
	// 		$userName = "01632144545";
	// 		$passWord = "bebcde4e7b";
			
	// 		$this->load->library("Nusoap_library");
	// 		$soapClient =  new nusoap_client("https://api2.onnorokomSMS.com/sendSMS.asmx?wsdl", 'wsdl');

	// 		//Soap Unicode Support
	// 		$soapClient->soap_defencoding = 'UTF-8';
	// 		$soapClient->decode_utf8 = false;

	// 		//OneToOne
			
	// 		$paramArray = array(
	// 			'userName'=>$userName,
	// 			'userPassword'=>$passWord, 
	// 			'mobileNumber'=> "01714415122", 
	// 			'smsText'=>"Single SMS Send from CodeIgniter Test", 
	// 			'type'=>"TEXT",
	// 			'maskName'=> "NewOffer", 
	// 			'campaignName'=>'',
	// 		);
	// 		echo "before calling method";
	// 		$value = $soapClient->call("OneToOne", $paramArray);			
	// 		echo 'output is '; print_r($value);
			
			
	// 		// One to Many 
	// 		/*
	// 		$paramArray = array(
	// 			'userName'=>$userName,
	// 			'userPassword'=>$passWord, 
	// 			'messageText'=>"Bulk SMS Send from CodeIgniter Test", 
	// 			'numberList'=> "01811444729,01833168163", 				
	// 			'smsType'=>"TEXT",
	// 			'maskName'=> "DemoMask", 
	// 			'campaignName'=>'',
	// 		);
	// 		echo "before calling method";
	// 		$value = $soapClient->call("OneToMany", $paramArray);			
	// 		echo 'output is '; print_r($value);
	// 		*/
		
	// 	}
	// 	catch (Exception $e) {
	// 		echo $e;
	// 	}

	// 	$this->load->view('welcome_message');
	// }

	public function index()
	{
		try
		{ 	
			$username = "monsur22";
			$hash = "7447906eadeb81f71afd5e7f8080e525"; //generate token from the control panel
			$numbers = "01714415122"; //Recipient Phone Number multiple number must be separated by comma
			$message = "Simple text message.";
		
		
			$params = array('app'=>'ws', 'u'=>$username, 'h'=>$hash, 'op'=>'pv', 'to'=>$numbers, 'msg'=>$message);
		
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "http://alphasms.biz/index.php?".http_build_query($params, '', '&'));
			curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type:application/json", "Accept:application/json"));
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		
			$response = curl_exec($ch);
			curl_close ($ch);
		
		}
		catch (Exception $e) {
			echo $e;
		}

		$this->load->view('welcome_message');
	}
}
